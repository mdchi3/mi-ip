document.addEventListener('DOMContentLoaded', () => {
  const loader = document.getElementById('loader');
  const content = document.getElementById('content');
  const ipVal = document.getElementById('ipVal');
  const cityVal = document.getElementById('cityVal');
  const regionVal = document.getElementById('regionVal');
  const countryVal = document.getElementById('countryVal');
  const orgVal = document.getElementById('orgVal');
  const copyBtn = document.getElementById('copyBtn');
  const donateBtn = document.getElementById('donateBtn');

  // Función para poblar la vista
  function renderData(data) {
    ipVal.textContent = data.ip || 'No disponible';
    cityVal.textContent = data.city || 'No disponible';
    regionVal.textContent = data.region || 'No disponible';
    countryVal.textContent = data.country || 'No disponible';
    orgVal.textContent = data.org || data.connection?.isp || 'No disponible';

    loader.style.display = 'none';
    content.style.display = 'block';
  }

  // Obtener datos primero de almacenamiento local para carga instantánea
  if (chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['cachedIpInfo', 'cachedTime'], (res) => {
      if (res && res.cachedIpInfo) {
        renderData(res.cachedIpInfo);
      }
    });
  }

  // Consultar IP y Geolocalización en vivo
  async function fetchIpDetails() {
    try {
      // Proveedor primario
      const response = await fetch('https://ipwho.is/');
      if (response.ok) {
        const data = await response.json();
        if (data && data.success !== false) {
          const info = {
            ip: data.ip,
            city: data.city,
            region: data.region,
            country: data.country,
            org: (data.connection && (data.connection.isp || data.connection.org)) || 'No disponible'
          };
          renderData(info);
          if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ cachedIpInfo: info, cachedTime: Date.now() });
          }
          return;
        }
      }
      throw new Error('Fallback required');
    } catch (e) {
      // Proveedor secundario (fallback)
      try {
        const fallbackRes = await fetch('https://ipapi.co/json/');
        if (fallbackRes.ok) {
          const fbData = await fallbackRes.json();
          const info = {
            ip: fbData.ip,
            city: fbData.city,
            region: fbData.region,
            country: fbData.country_name,
            org: fbData.org || fbData.asn || 'No disponible'
          };
          renderData(info);
          if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ cachedIpInfo: info, cachedTime: Date.now() });
          }
          return;
        }
      } catch (err) {
        loader.textContent = 'Error al obtener la información de IP. Verifica tu conexión.';
      }
    }
  }

  fetchIpDetails();

  // Botón para copiar la dirección IP
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const textToCopy = ipVal.textContent;
      if (textToCopy && textToCopy !== '--' && textToCopy !== 'No disponible') {
        navigator.clipboard.writeText(textToCopy).then(() => {
          copyBtn.textContent = '¡Copiado!';
          setTimeout(() => {
            copyBtn.textContent = 'Copiar';
          }, 1800);
        });
      }
    });
  }

  // Botón Donar a Mercado Pago
  if (donateBtn) {
    donateBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://link.mercadopago.com.ar/marianodamian' });
    });
  }
});
